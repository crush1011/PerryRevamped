package RealBot;

/**
 * Created by raque on 10/12/2017.
 */
public class RobotConfig {

    public double maxAccel, maxSpeed, botWidth, botLength;

    public RobotConfig(double maxAccel, double maxSpeed, double botWidth, double botLength) {
        this.maxAccel = maxAccel;
        this.maxSpeed = maxSpeed;
        this.botWidth = botWidth;
        this.botLength=botLength;
    }
}
