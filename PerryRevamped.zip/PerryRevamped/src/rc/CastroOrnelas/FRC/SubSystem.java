package rc.CastroOrnelas.FRC;

public interface SubSystem {

	public void test();
	public void log();
	public void writeToSmartDashboard();
	public void startLoops();
}
