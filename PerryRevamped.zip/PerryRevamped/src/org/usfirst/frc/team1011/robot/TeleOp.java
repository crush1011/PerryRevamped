package org.usfirst.frc.team1011.robot;

public class TeleOp {

	public static void init() {
		
	}
}
