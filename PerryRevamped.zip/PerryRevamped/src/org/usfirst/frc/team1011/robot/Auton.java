package org.usfirst.frc.team1011.robot;

public class Auton {

	public static void init() {

	}
}
